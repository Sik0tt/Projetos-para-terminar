var lista_atributos = document.getElementById("lista_atributos");
var lista_raças = document.getElementById("lista_raças");
var lista_classes = document.getElementById("lista_classes")
var atributos = document.getElementById("atributos");
var raças = document.getElementById("raças");
var classes = document.getElementById("classes")
var imagem = document.getElementById("imagem");
var btnCarregar = document.getElementById("carregar");

var vatSelect = [];
var vraSelect = [];
var vclaSelect = [];


function opções_atributos(){
    var vat = [];
    vat.push("Força");
    vat.push("Destreza");
    vat.push("Inteligencia");
    vat.push("Sabedoria");
    vat.push("Carisma");
    vat.push("Constituição");
    
    lista_atributos.innerHTML = "";
    vat.forEach(function(item){
        var op = document.createElement("option");
        op.text = item;
        op.value = item;
        lista_atributos.add(op);
    });
}

function adicionarAtributo(){
    if(atributos.length<3){
        var valor = lista_atributos.options[lista_atributos.selectedIndex].text;
        var op = document.createElement("option");
        op.text = valor;
        op.value = valor;
        atributos.add(op);
        lista_atributos.options[lista_atributos.selectedIndex].remove();
        vatSelect.push(valor);
    }else{
        alert("Não é permitido mais de 3 atributos!");
    }
    
}

function removerAtributo(){
    var valor = atributos.options[atributos.selectedIndex].text;
    var op = document.createElement("option");
    op.text = valor;
    op.value = valor;
    lista_atributos.add(op);
    atributos.options[atributos.selectedIndex].remove();
    for( var i = 0; i < vatSelect.length; i++){ 
        if ( vatSelect[i] === valor) { 
            vatSelect.splice(i, 1); 
        }
    }
}

function listaRaças(){
    var vra = [];
    vra.push("Humano");
    vra.push("Elfo");
    vra.push("Goblin");
    vra.push("Lefou");
    vra.push("Minotauro");
    vra.push("Qareen");
    vra.push("Golem");
    vra.push("Anão");
    vra.push("Trog");
    vra.push("Suraggel");
    vra.push("Sílfide ");
    vra.push("Osteon");
    vra.push("Sereia/Tritão");
    vra.push("Kliren");
    vra.push("Medusa ");
    vra.push("Hynne");
    vra.push("Dahllan");
    lista_raças.innerHTML = "";
    vra.forEach(function(item){
        var op = document.createElement("option");
        op.text = item;
        op.value = item;
        lista_raças.add(op);
    });
}

function adicionarRaça(){
    if(raças.length<1){
        var valor = lista_raças.options[lista_raças.selectedIndex].text;
        var op = document.createElement("option");
        op.text = valor;
        op.value = valor;
        raças.add(op);
        lista_raças.options[lista_raças.selectedIndex].remove(); 
        vraSelect.push(valor);
    }else{
        alert("Você só pode adicionar 1 raça!");
    }
}

function removerRaça(){
    var valor = raças.options[raças.selectedIndex].text;
    var op = document.createElement("option");
}

function opções_classes(){
    var vcla = [];
    vcla.push("Arcanista");
    vcla.push("Bárbaro");
    vcla.push("Bardo");
    vcla.push("Bucaneiro");
    vcla.push("Caçador");
    vcla.push("Cavaleiro");
    vcla.push("Clérigo");
    vcla.push("Druida");
    vcla.push("Guerreiro");
    vcla.push("Inventor");
    vcla.push("Ladino");
    vcla.push("Lutador");
    vcla.push("Nobre");
    vcla.push("Paladino");
    
    lista_classes.innerHTML = "";
    vcla.forEach(function(item){
        var op = document.createElement("option");
        op.text = item;
        op.value = item;
        lista_classes.add(op);
    });
}

function adicionarClasse(){
    if(classes.length<1){
        var valor = lista_classes.options[lista_classes.selectedIndex].text;
        var op = document.createElement("option");
        op.text = valor;
        op.value = valor;
        classes.add(op);
        lista_classes.options[lista_classes.selectedIndex].remove(); 
        vclaSelect.push(valor);
    }else{
        alert("Você só pode adicionar 1 classe!");
    }
}

function removerClasse(){
    var valor = classes.options[classes.selectedIndex].text;
    var op = document.createElement("option");
}

function pegarImagem(){
    document.getElementById("card").style.display = "none";
    if(this.files && this.files[0]){ 
        var file = new FileReader(); 
        file.onload = function(arquivo){ 
            document.getElementById("imagem_card").src = arquivo.target.result; 
        }
        file.readAsDataURL(this.files[0]); 
    };
    console.log("a")
}

function mostrarCard(){
    var nome = document.getElementById("nome").value;
    var descricao = document.getElementById("descricao").value;
    var genero = document.getElementsByName("genero")
    var generoSelected
    for(var r of genero){
        if(r.checked){
            generoSelected=r.value;
        }
    }
    //nome
    if(nome != null && nome != ""){
        document.getElementById("nome_carta").innerHTML = "Nome: "+nome;
    }else{
        alert("Adicione um nome ao seu carta.");
        return;
    };
    //descrição
    if(descricao != null && descricao != ""){
        document.getElementById("descricao_carta").innerHTML = descricao;
    }else{
        alert("Adicione uma descrição à sua carta.");
        return;
    };
    //poderes
    if(vatSelect.length>0){
        for(i=1;i<vatSelect.length;i++){
            vatSelect[i]=" "+vatSelect[i];
        }
        document.getElementById("atributos_persona").innerHTML = "Atributos: "+vatSelect;
    }else{
        alert("Adicione pelo menos um atributo ao seu personagem.");
        return;
    };
    //fraqueza
    if(vraSelect.length>0){
        document.getElementById("raça_persona").innerHTML = "Raça: "+vraSelect;
    }else{
        alert("Adicione uma raça à sua carta.");
        return;
    };
    //genero
    if(generoSelected=="Masculino" || generoSelected=="Feminino"){
        document.getElementById("genero").innerHTML = "Gênero: "+generoSelected;
        document.getElementById("div_genero_opcional").style.display = "block";
    }else{
        document.getElementById("div_genero_opcional").style.display = "none";
    }
    //imagem
    if(imagem.value != null && imagem.value != ""){ 
        document.getElementById("card").style.display = "block";
    }
    
    document.getElementById("div_atributos_carta").style.display = "block";
    document.getElementById("div_visualizacao_carta2").style.display = "block";
    reset();
}

lista_atributos.addEventListener("click", adicionarAtributo);
atributos.addEventListener("click", removerAtributo);
lista_raças.addEventListener("click", adicionarRaça);
raças.addEventListener("click", removerRaça);
lista_classes.addEventListener("click", adicionarClasse);
classes.addEventListener("click", removerClasse);
btnCarregar.addEventListener("click", mostrarCard);
imagem.addEventListener("change", pegarImagem);


opções_atributos();
listaRaças();
opções_classes();
